package org.example;

public class OportunidadeEstudo {

    private final static double NOTA_MAIOR_IGUAL_9 = 0.70;
    private final static double NOTA_MAIOR_IGUAL_8 = 0.50;
    private final static double NOTA_MAIOR_IGUAL_7 = 0.30;
    private final static double NOTA_MENOR_7 = 0.00;
    private final static double RENDA_MENOR_2000 = 0.20;
    private final static double RENDA_MENOR_4000 = 0.10;
    private final static double RENDA_MAIOR_IGUAL_4000 = 0.00;
    private final static double POS_GRADUACAO = 0.10;
    private final static double CURSO_TECNICO = 0.05;


    public  static double calcularBolsa(double rendaMensal, double nota, String curso){

        double percentual;

        if(nota >= 9)
            percentual = NOTA_MAIOR_IGUAL_9;
        else if(nota >= 8 && nota < 9)
            percentual = NOTA_MAIOR_IGUAL_8;
        else if(nota >= 7 && nota < 8)
            percentual = NOTA_MAIOR_IGUAL_7;
        else
            percentual = NOTA_MENOR_7;

        if(rendaMensal < 2000)
            percentual += RENDA_MENOR_2000;
        else if(rendaMensal < 4000 && rendaMensal >= 2000)
            percentual += RENDA_MENOR_4000;
        else
            percentual += RENDA_MAIOR_IGUAL_4000;

        if("Pós-Graduação".equals(curso))
            percentual -= POS_GRADUACAO;
        else if("Curso Técnico".equals(curso))
            percentual += CURSO_TECNICO;

        if(percentual < 0)
            percentual = 0;
        else if(percentual > 1)
            percentual = 1;


        return percentual;

    }





    public static void main(String args[]){


        System.out.println(OportunidadeEstudo.calcularBolsa(2000,8,"Curso Técnico"));



    }


}
