import org.example.OportunidadeEstudo;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OportunidadeEstudoTest {

    private static final double DELTA = 0.0001;

    @Test
    public void testeAlunoNota95Renda1500Graduacao() {
        // Nota 9.5 → 70%
        // Renda 1500 (< 2000) → +20%
        // Curso graduação → 0%
        // Total esperado: 90%
        double resultado = OportunidadeEstudo.calcularBolsa(1500, 9.5, "graduacao");
        assertEquals(90.0, resultado, DELTA);
    }

    @Test
    public void testeAlunoNota85Renda3500Pos() {
        // Nota 8.5 → 50%
        // Renda 3500 (< 4000) → +10%
        // Curso pós-graduação → -10%
        // Total esperado: 50%
        double resultado = OportunidadeEstudo.calcularBolsa(3500, 8.5, "pos");
        assertEquals(50.0, resultado, DELTA);
    }

    @Test
    public void testeAlunoNota7Renda4500Tecnico() {
        // Nota 7 → 30%
        // Renda 4500 (>= 4000) → +0%
        // Curso técnico → +5%
        // Total esperado: 35%
        double resultado = OportunidadeEstudo.calcularBolsa(4500, 7.0, "tecnico");
        assertEquals(35.0, resultado, DELTA);
    }

    @Test
    public void testeAlunoNota5Renda5000Graduacao() {
        // Nota 5 → 0%
        // Renda 5000 (>= 4000) → +0%
        // Curso graduação → 0%
        // Total esperado: 0%
        double resultado = OportunidadeEstudo.calcularBolsa(5000, 5.0, "graduacao");
        assertEquals(0.0, resultado, DELTA);
    }

    @Test
    public void testeLimiteNota10Renda1000Tecnico() {
        // Nota 10 → 70%
        // Renda 1000 (< 2000) → +20%
        // Curso técnico → +5%
        // Total: 95%, mas limite máximo é 100%
        double resultado = OportunidadeEstudo.calcularBolsa(1000, 10.0, "tecnico");
        assertEquals(95.0, resultado, DELTA);
    }
}