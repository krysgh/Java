import org.example.CheckoutPedido;

public class checkoutPedidoTest {

    CheckoutPedido pedido = new CheckoutPedido();




}
