import org.example.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CheckoutPedidoTest {

    private static final CheckoutPedido pedido = new CheckoutPedido();
    private static final double DELTA = 0.0001;


    @Test
    public void validarStatusProduto(){
            assertThrows(IllegalArgumentException.class, () ->{

            pedido.calcularTotal(new Produto("Caderno",40.00, "Papelaria", 2, 4, false, "Capital"), new Cupom("PRIMEIRA COMPRA 10%", 0.10, 50000, 10));

            });
        }

    @Test
    public void validarQntPositiva(){
        assertThrows(IllegalArgumentException.class, () -> {

            pedido.calcularTotal(new Produto("Lapiseira", 10, "Papelaria", 0, 2,true, "INTERIOR"),new Cupom("PRIMEIRA COMPRA 10%", 0.10,50000,10));
            pedido.calcularTotal(new Produto("Lapiseira", 10, "Papelaria", -5, 2,true, "INTERIOR"),new Cupom("PRIMEIRA COMPRA 10%", 0.10,50000,10));

        });
    }

    @Test
    public void validarCategoriaELETRONICO(){

        Produto celular = new Produto("Smartphone Galaxy A26 8/256 5G", 1400, "ELETRÔNICO", 1000, 40,true, "CAPITAL");
        Cupom primeiracompra = new Cupom("PRIMEIRA COMPRA 10%", 0.10,1000,10);

        // total = 1400 (preco do produto) + ICMS (1400 * 0.18) + FRETE GRÁTIS (preco > 200) - CUPOM DE DESCONTO ATIVO (10%) = 1486.8

        assertEquals(1486.8,pedido.calcularTotal(celular,primeiracompra),DELTA,"Erro no cálculo do ICMS para a categoria ELETRÔNCO");

    }

    @Test
    public void validarFreteGratis(){

        Produto cobertor = new Produto("Kit Cobertor", 300, "CAMA", 50, 20,true, "CAPITAL");
        Cupom promocama = new Cupom("PROMOÇÃO KIT CAMA 20%", 0.20,300,5);

        // // total = 300 (preco do produto) + FRETE GRÁTIS (preco > 200) - CUPOM DE DESCONTO ATIVO (20%) = 240

        assertEquals(240,pedido.calcularTotal(cobertor,promocama),DELTA,"Erro no cálculo de Frete Grátis");

    }




    }


