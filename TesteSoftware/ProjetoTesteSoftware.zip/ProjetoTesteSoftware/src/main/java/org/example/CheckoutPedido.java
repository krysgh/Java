package org.example;

public class CheckoutPedido {

    public static double ICMS_ELETRONICO = 0.18;
    public static double TETO_FRETE_GRATIS = 200.0;
    public static final double FRETE_GRATIS = 0.0;
    public static final double FRETE_PADRAO = 20.0;
    public static final double FRETE_REGIAO = 30.0;
    public static final double CASHBACK = 0.01;


    public static void calcularTotal(Produto produto, Cupom cupom){

        double total = 0.0;

        //VALIDAÇÃO DO STATUS DO PRODUTO
        if(!produto.isStatus() && produto.getQuantidade() > 0){

            //VALIDA SE A CLASSIFICACAO EH "ELETRONICO" PARA APLICAR O IMPOSTO ICMS
            if("ELETRONICO".equals(produto.getCategoria())){
                total *= 1 + ICMS_ELETRONICO;
            }


            if(produto.getPreco() >= TETO_FRETE_GRATIS){
                total += FRETE_GRATIS;
            }
            else if("INTERIOR".equals(produto.getRegiao())){
                total += FRETE_REGIAO;
            }
            else{
                total += FRETE_PADRAO;
            }

        }
        else{
            System.out.println("PRODUTO INATIVO");
        }

    }



    public static void main(String[] args){
    Cupom primeiraCompra = new Cupom("PRIMEIRA COMPRA 10%",0.10,500000, 10 );
    Produto p = new Produto("Caderno", 12.59,"Papelaria",53,20, true,"CAPITAL");
    System.out.println(p.toString());
    }



}
