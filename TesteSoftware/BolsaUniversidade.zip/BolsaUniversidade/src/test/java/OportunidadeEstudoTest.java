import org.example.OportunidadeEstudo;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OportunidadeEstudoTest {

    private final static double DELTA = 0.0001;

    @Test
    public void validarNotaMaiorIgual9(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );

    }

    @Test
    public void validarNotaMaiorIgual8(){

        double notaMaiorIgual8 = OportunidadeEstudo.calcularBolsa(3000,8,"Curso Técnico");

        // 0.50 + 0.10 - 0.05 = 0.65

        assertEquals("Erro ao validar nota >= 8", 0.65, notaMaiorIgual8, DELTA );


    }

    @Test
    public void validarNotaMaiorIgual7(){


        double notaMaiorIgual7 = OportunidadeEstudo.calcularBolsa(1000,7,"Pós-Graduação");

        // 0.20 + 0.30 - 0.10 = 0.40

        assertEquals("Erro ao validar nota >= 7", 0.40, notaMaiorIgual7, DELTA );


    }

    @Test
    public void validarNotaMenor7(){

        double notaMenor7 = OportunidadeEstudo.calcularBolsa(2000,6,"Curso Técnico");

        // 0.70 + 0.10 + 0.05 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void validarNotaMenor2000(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void notaMaiorIgual(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void notaMaiorIgua(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void notaMaiorIgu(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void notaMaiorIg(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }

    @Test
    public void notaMaiorI(){

        double notaMaiorIgual9 = OportunidadeEstudo.calcularBolsa(2000,9,"Pós-Graduação");

        // 0.70 + 0.10 - 0.10 = 0.70

        assertEquals("Erro ao validar nota >= 9", 0.70, notaMaiorIgual9, DELTA );


    }
}
