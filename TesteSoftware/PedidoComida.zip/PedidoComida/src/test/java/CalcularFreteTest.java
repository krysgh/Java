import org.example.CalcularFrete;
import org.example.Comida;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

public class CalcularFreteTest {

    private CalcularFrete calcularFrete = new CalcularFrete();

    @Test
    public void testeFreteGratis() {
        Comida produto = new Comida("Sushi Combo", 150, 7);
        double resultadoEsperado = 150;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals("O frete deve ser grátis para produtos acima de R$100.", resultadoEsperado, resultadoReal, 0.001 );
    }

    @Test
    public void testeFreteDistanciaCurta() {
        Comida produto = new Comida("Pizza", 60, 3);
        double resultadoEsperado = 60 + 6.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals("O frete para distância <= 3km deve ser R$6.99.",resultadoEsperado, resultadoReal, 0.001);
    }

    @Test
    public void testeFreteDistanciaMedia() {
        Comida produto = new Comida("Burger", 40, 5);
        double resultadoEsperado = 40 + 9.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals("O frete para 3km < distância <= 6km deve ser R$9.99.",resultadoEsperado, resultadoReal, 0.001);
    }

    @Test
    public void testeFreteDistanciaLonga() {
        Comida produto = new Comida("HotDog", 20, 7);
        double resultadoEsperado = 20 + 14.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals("O frete para distância > 6km deve ser R$14.99.", resultadoEsperado, resultadoReal, 0.001);
    }
}