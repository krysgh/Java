package org.example;

public class EditorBasico implements EditorTexto {
    @Override
    public String escrever(String texto) {
        return texto;
    }
}
