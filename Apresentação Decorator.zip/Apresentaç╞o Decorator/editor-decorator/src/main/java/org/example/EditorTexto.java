package org.example;

public interface EditorTexto {
    String escrever(String texto);
}
