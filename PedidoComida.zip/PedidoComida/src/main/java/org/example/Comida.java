package org.example;

public class Comida {

    private String nome;
    private double preco;
    private double distancia;

    public Comida(String nome, double preco, double distancia) {
        this.nome = nome;
        this.preco = preco;
        this.distancia = distancia;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }


}
