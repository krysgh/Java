package org.example;

public class CalcularFrete {
    public static void main(String[] args) {

        double sushi = 120;
        double pizza = 60;
        double hamburguer = 40;

        double distancia1 = 5;
        double distancia2 = 3;
        double distancia3 = 7;

        CalcularFrete p = new CalcularFrete();

        double result = p.calcularFrete(pizza, distancia3);
        System.out.println(result);

    }

    public double calcularFrete(double comida, double distancia) {

        double result = 0;

        if (comida >= 100) {
            result = comida;
        }

        else if (distancia <= 3) {
            result =comida + 6.99;
        }

        else if (distancia > 3 && distancia <= 6) {
            result =comida + 9.99;
        }

       else  if(distancia >6){
            result = comida + 14.99;
        }

        return result;
    }
}


