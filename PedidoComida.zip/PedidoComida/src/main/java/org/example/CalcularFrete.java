package org.example;

public class CalcularFrete{
    public static void main(String[] args) {

        CalcularFrete p = new CalcularFrete();

        Comida sushi_combo = new Comida("Sushi Combo",150,7);
        double resultSushi = p.calcularFrete(sushi_combo);
        System.out.println("SUSHI COMBO TOTAL: R$" + resultSushi);

        Comida pizza = new Comida("Pizza",60,3);
        double resultPizza = p.calcularFrete(pizza);
        System.out.println("PIZZA TOTAL: R$" + resultPizza);

        Comida burger = new Comida("Burger",40,5);
        double resultBurger = p.calcularFrete(burger);
        System.out.println("BURGER TOTAL: R$" + resultBurger);

        Comida hotdog = new Comida("HotDog",20,7);
        double resultHotDog = p.calcularFrete(hotdog);
        System.out.println("HOTDOG TOTAL: R$" + resultHotDog);

    }

    public double calcularFrete(Comida produto) {

        double result = 0;

        if (produto.getPreco() >= 100) {
            result = produto.getPreco();
        }

        else if (produto.getDistancia() <= 3) {
            result = produto.getPreco() + 6.99;
        }

        else if (produto.getDistancia() > 3 && produto.getDistancia() <= 6) {
            result =produto.getPreco() + 9.99;
        }

       else  if(produto.getDistancia() >6){
            result =produto.getPreco() + 14.99;
        }

        return result;
    }
}


