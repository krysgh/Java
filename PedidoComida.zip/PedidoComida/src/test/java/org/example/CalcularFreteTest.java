package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalcularFreteTest {

    private CalcularFrete calcularFrete = new CalcularFrete();

    @Test
    void testeFreteGratis() {
        Comida produto = new Comida("Sushi Combo", 150, 7);
        double resultadoEsperado = 150;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals(resultadoEsperado, resultadoReal, 0.001, "O frete deve ser grátis para produtos acima de R$100.");
    }

    @Test
    void testeFreteDistanciaCurta() {
        Comida produto = new Comida("Pizza", 60, 3);
        double resultadoEsperado = 60 + 6.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals(resultadoEsperado, resultadoReal, 0.001, "O frete para distância <= 3km deve ser R$6.99.");
    }

    @Test
    void testeFreteDistanciaMedia() {
        Comida produto = new Comida("Burger", 40, 5);
        double resultadoEsperado = 40 + 9.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals(resultadoEsperado, resultadoReal, 0.001, "O frete para 3km < distância <= 6km deve ser R$9.99.");
    }

    @Test
    void testeFreteDistanciaLonga() {
        Comida produto = new Comida("HotDog", 20, 7);
        double resultadoEsperado = 20 + 14.99;
        double resultadoReal = calcularFrete.calcularFrete(produto);
        assertEquals(resultadoEsperado, resultadoReal, 0.001, "O frete para distância > 6km deve ser R$14.99.");
    }
}