public class CalcularFreteTest {

    public void testCalcularFrete() {
        System.out.println("teste");
    }
}
