import org.example.FreteService;
import org.example.Pedido;
import org.junit.Assert;
import org.junit.Test;

public class FreteServiceTest {

    private  final FreteService fs = new FreteService();
    private static final double DELTA = 0.0001;

    @Test (expected = IllegalArgumentException.class)
    public void validarDistanciaNegativa(){

        fs.calcularFrete(new Pedido(100.0, -1, 2, false,false));
    }

    @Test (expected = IllegalArgumentException.class)
    public void validarDeveRejeitarPesonegativo(){

        fs.calcularFrete((new Pedido(100,10,-1,false,false)));
    }

    @Test
    public void validarBasePorDistanciaPercorrida(){
        Pedido p = new Pedido(50.0,10.0,3.0,false,false);

        //10KM * 1.20 = 12 reais (nao entra em nenhuma outra regra de negocio)

        Assert.assertEquals(12.0,fs.calcularFrete(p), DELTA);

    }

    @Test
    public void validarExcessoPesoAcimaLimite(){
        Pedido pNoLimite = new Pedido(50.0,10.0,5.0,false,false);
        Pedido pAcimaLimite = new Pedido(50.0,10.0,5.5,false,false);

        //No Limite, 10 *1.2 = 12
        //Acima do Limite 10*1.2 + 0.5*2 = 13

        Assert.assertEquals(12,fs.calcularFrete(pNoLimite),DELTA);
        Assert.assertEquals(13, fs.calcularFrete(pAcimaLimite), DELTA);

    }

    @Test
    public void validarFragil(){
        Pedido p = new Pedido( 80.0, 10.0, 6.0, true, false );

        //10 * 1.2 + 1 * 2 + 15 = 29

        Assert.assertEquals(29.0, fs.calcularFrete(p),DELTA);
    }

    @Test
    public void validarExpresso(){
        Pedido p = new Pedido(90.0, 5.0, 2.0, false, true);

        //5 * 1.2 *1.5 = 9 (<10) = 10

        Assert.assertEquals(10, fs.calcularFrete(p), DELTA);
    }

    @Test
    public void validarFreteGratis(){
        Pedido gratis = new Pedido(220.0,20.0,2.0, false, false);

        //

        Assert.assertEquals(0.0, fs.calcularFrete(gratis), DELTA);
    }

}
