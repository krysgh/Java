package org.example;

public class FreteService {

    private static final double BASE_POR_KM = 1.20;
    private static final double EXCESSO_PESO_LIMITE_KG = 5.0;
    private static final double EXCESSO_PESO_TAXA_POR_KG = 2.0;
    private static final double TAXA_FRAGIL = 15.0;
    private static final double MULTIPLICADOR_EXPRESSO = 1.5;
    private static final double MINIMO = 10.0;
    private static final double MAXIMO = 300.0;
    private static final double VALOR_FRETE_GRATIS = 200.0;
    private static final double DISTANCIA_FRETE_GRATIS = 20.0;



    public double calcularFrete(Pedido pedido){

        double total = 0.0;

        validar(pedido);

        total += pedido.getDistanciaKm() * BASE_POR_KM;

        if(pedido.getPesoKg() > EXCESSO_PESO_LIMITE_KG){
            double excesso = pedido.getPesoKg() - EXCESSO_PESO_LIMITE_KG;
            total += excesso * EXCESSO_PESO_TAXA_POR_KG;
        }

        if(pedido.isFragil()){
            total += TAXA_FRAGIL;
        }

        if(pedido.isExpresso()){
            total*= MULTIPLICADOR_EXPRESSO;
        }

        total = Math.max(MINIMO, Math.min(MAXIMO, total));

        if(pedido.getValorItens() > VALOR_FRETE_GRATIS && pedido.getDistanciaKm() <= DISTANCIA_FRETE_GRATIS && !pedido.isExpresso()){
            total = 0.0;
        }

        return total;
    }

    private void validar(Pedido pedido){

        if(pedido.getDistanciaKm()< 0) throw new IllegalArgumentException("Distância não pode ser negativa.");

        if(pedido.getPesoKg() < 0) throw new IllegalArgumentException("Peso não pode ser negativo.");
    }


    public static void main(String[] args){

        Pedido padrao = new Pedido(150.0,30.0,5.5,false,false);

        Pedido fragil = new Pedido(80.0,10.0,8.0,true,false);

        Pedido expresso = new Pedido(90.0,5.0,2.0,false,true);

        Pedido gratis = new Pedido(250.0,15.0,3.0,false, false);

        FreteService fs = new FreteService();

        System.out.println("Frete Padrão: " + fs.calcularFrete(padrao));
        System.out.println("Frete Frágil: " + fs.calcularFrete(fragil));
        System.out.println("Frete Expresso: " + fs.calcularFrete(expresso));
        System.out.println("Frete Grátis: " + fs.calcularFrete(gratis));


    }

}
