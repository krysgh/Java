import org.example.FreteService;
import org.example.Pedido;
import org.junit.Test;

public class FreteServiceTest {

    private  final FreteService fs = new FreteService();

    @Test (expected = IllegalArgumentException.class)
    public void validarDistanciaNegativa(){

        fs.calcularFrete(new Pedido(100.0, -1, 2, false,false));
    }

    @Test (expected = IllegalArgumentException.class)
    public void validarDeveRejeitarPesonegativo(){

        fs.calcularFrete((new Pedido(100,10,-1,false,false)));
    }

}
